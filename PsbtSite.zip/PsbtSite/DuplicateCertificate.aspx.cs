﻿using PsbtSite.Data;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PsbtSite
{
    public partial class DuplicateCertificate : System.Web.UI.Page
    {
        private pstbt_dbEntities _datacontext;
        protected void Page_Load(object sender, EventArgs e)
        {
            _datacontext = new pstbt_dbEntities();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            dupcertificate objcertificate = new dupcertificate
            {
                Name = txtName.Text,
                email = txtEmail.Text,
                Examination = txtExam.Text,
                fees = Convert.ToDecimal(txtFees.Text),
                FName = txtFname.Text,
                Institute = txtInstitute.Text,
                ObtMark = Convert.ToInt32(txtMarkObt.Text),
                TotalMark = Convert.ToInt32(txtTotal.Text),
                Office = txtOffice.Text,
                Reason = txtReason.Text,
                RegNo = Convert.ToInt32(txtRegNo.Text),
                RollNo = Convert.ToInt32(txtRollNo.Text),
                Session = Convert.ToInt32( txtSession.Text)
            };

            _datacontext.dupcertificates.Add(objcertificate);
            _datacontext.SaveChanges();

            string key = "rzp_test_ovpTAFCggDsvQX";
            string secret = "3vXSQfz84ARW53DOKCZPKb08";
            RazorpayClient client = new RazorpayClient(key, secret);
            System.Net.ServicePointManager.SecurityProtocol =
SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            Dictionary<string, object> options = new Dictionary<string, object>();
            options.Add("amount", 100); // amount in the smallest currency unit
            options.Add("receipt", "order_rcptid_" + objcertificate.ID);
            options.Add("currency", "INR");
            options.Add("payment_capture", "0");
            Order order = client.Order.Create(options);


            Response.Redirect("~/PaymentPage.aspx?Order_Id=" + order.Attributes["id"] + "&name=" + objcertificate.Name + "&email=" + objcertificate.email + "&contact=" + txtPhone.Text);
        }
    }
}