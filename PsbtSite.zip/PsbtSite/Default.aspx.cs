﻿using PsbtSite.Data;
using Razorpay.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace PsbtSite
{
    public partial class Default : System.Web.UI.Page
    {
        private pstbt_dbEntities _datacontext;
        protected void Page_Load(object sender, EventArgs e)
        {
            _datacontext = new pstbt_dbEntities();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            certificate objcertificate = new certificate
            {
                ID = 1,
                CourseType = rdodiploma.Checked ? 1 : 2,
                RegNo = Convert.ToInt32(txtRegNo.Text),
                Name = txtstname.Text,
                Course = txtcourse.Text,
                Institute = txtInstitute.Text,
                ModofDel = delmod1.Checked ? 1 : 2,
                Address = txtAddress.Text,
                Phone1 = txtPhone1.Text,
                Phone2 = txtPhone2.Text,
                RegCard = idcc1.Checked ? 1 : 0,
                DetailMarkCard = idcc2.Checked ? 1 : 0,
                TanCert = idcc3.Checked ? 1 : 0,
                DiplomaCert = idcc4.Checked ? 1 : 0,
                OldName = txtoldname.Text,
                OldFName = txtoldfname.Text,
                NewName = txtnewname.Text,
                NewFName = txtnewfname.Text,
                NoObjCert = chkNoobj.Checked ? 1 : 0,
                OtherText = txtOther.Text,
                DateOfSub = txtDateofSub.Text,
                fees = Convert.ToDecimal(txtFees.Text),
                email = txtEmail.Text
            };

            _datacontext.certificates.Add(objcertificate);
            _datacontext.SaveChanges();
             
            string key = "rzp_test_ovpTAFCggDsvQX";
            string secret = "3vXSQfz84ARW53DOKCZPKb08";
            RazorpayClient client = new RazorpayClient(key, secret);
            System.Net.ServicePointManager.SecurityProtocol =
SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            Dictionary<string, object> options = new Dictionary<string, object>();
            options.Add("amount", 100); // amount in the smallest currency unit
            options.Add("receipt", "order_rcptid_" + objcertificate.ID);
            options.Add("currency", "INR");
            options.Add("payment_capture", "0");
            Order order = client.Order.Create(options); 


            Response.Redirect("~/PaymentPage.aspx?Order_Id=" + order.Attributes["id"] + "&name=" + objcertificate.Name + "&email=" + objcertificate.email + "&contact=" + objcertificate.Phone1);
             

        }
    }
}