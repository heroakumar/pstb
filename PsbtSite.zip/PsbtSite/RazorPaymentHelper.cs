﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using PsbtSite.Data;
using Razorpay.Api;
namespace PsbtSite
{
    public class RazorPaymentHelper
    {
        public string MakePayment(decimal amount, certificate _certificate)
        {   
            

            string key = "rzp_test_ovpTAFCggDsvQX";
            string secret = "3vXSQfz84ARW53DOKCZPKb08";
            RazorpayClient client = new RazorpayClient(key, secret);
            System.Net.ServicePointManager.SecurityProtocol =
SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            Dictionary<string, object> options = new Dictionary<string, object>();
            options.Add("amount", 100); // amount in the smallest currency unit
            options.Add("receipt", "order_rcptid_11");
            options.Add("currency", "INR");
            options.Add("payment_capture", "0");
            Order order = client.Order.Create(options);


            Dictionary<string, object> optionsCustomer = new Dictionary<string, object>();

            optionsCustomer.Add("name", _certificate.Name);
            optionsCustomer.Add("contact", _certificate.Phone1);
            optionsCustomer.Add("email", "foo@example.com");
            optionsCustomer.Add("fail_existing", 0);

            Customer customer =client.Customer.Create(optionsCustomer);


            //Order order = client.Order.Create(options);
            //RazorpayClient client = new RazorpayClient(key, secret);

            //Dictionary<string, object> options = new Dictionary<string, object>();
            //options.Add("amount", 1);
            //options.Add("currency", "INR");


            return "";
        }
    }
}